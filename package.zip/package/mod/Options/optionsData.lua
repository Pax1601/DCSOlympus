cdata =
{
	-- Module on/off

	Olympus_MODULE_ENABLED_LABEL				= _("Olympus Module Enabled"),

}
