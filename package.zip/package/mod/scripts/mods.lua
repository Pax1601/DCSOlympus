-- Enter here any mods required by your mission as in the example below.
-- Possible categories are:
-- Aircraft
-- Helicopter
-- GroundUnit
-- NavyUnit

Olympus.modsList = {
	["A-4E-C"] = "Aircraft",
	["Bronco-OV-10A"] = "Aircraft"
}
